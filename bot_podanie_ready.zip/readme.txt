
Instrukcja:
1. Wrzucić pliki na GitHub.
2. Połączyć z Railway: https://railway.app/
3. Kliknąć "Deploy" na Railway, aby uruchomić bota.
4. Używać komendy /podanie na serwerze Discord.
    